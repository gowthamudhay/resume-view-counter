import azure.functions as func

# Simple counter stored in memory
view_count = 0

app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)

@app.route(route="viewcounter")
def main(req: func.HttpRequest) -> func.HttpResponse:
    global view_count
    view_count += 1
    return func.HttpResponse(f"👔 Resume Views: {view_count}", status_code=200)